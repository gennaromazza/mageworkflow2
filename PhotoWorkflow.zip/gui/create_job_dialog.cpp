#include "create_job_dialog.h"

CreateJobDialog::CreateJobDialog(QWidget *parent) : QDialog(parent) {
    // Setup UI and connect signals/slots
}

CreateJobDialog::~CreateJobDialog() {
    // Cleanup
}
